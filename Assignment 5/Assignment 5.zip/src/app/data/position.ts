export class Position {
    _id: string;
    PositionName: string;
    PositionDescription: string;
    PositionBaseSalary: number;
    __v: number;
}