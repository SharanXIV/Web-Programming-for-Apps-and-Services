/*********************************************************************************
* WEB422 – Assignment 2
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Heroku URL for part 2: https://fathomless-oasis-93982.herokuapp.com/
*
** Name: Sharan Shanmugaratnam Student ID: 153601174 Date: 2019-09-27
*
*******************************************************************************/ 

var employeesModel = [];

function initializeEmployeesModel() {
    $.ajax({
        url: "https://fathomless-oasis-93982.herokuapp.com/employees",
        type: "GET",
        contentType: "application/json"
    }).done(function (data) {
        employeesModel = data;
        refreshEmployeeRows(employeesModel);
    }).fail(function (error) {
        showGenericModal('Error', "Unable to get employees.");
    })
}

function showGenericModal(title, message) {
    $('.modal-title').empty().append(title);
    $('.modal-body').empty().append(message);

    $("#genericModal").modal({
        backdrop: 'static',
        keyboard: false
    });
}

function refreshEmployeeRows(employees) {
    $('#employeeTable').empty();

    let templateTable = _.template(
        '<% _.forEach(employees, function(employee){ %>' +
        '<div class="row body-row" data-id=<%- employee._id %>>' +
        '<div class="col-xs-4 body-column"><%- employee.FirstName %></div>' +
        '<div class="col-xs-4 body-column"><%- employee.LastName %></div>' +
        '<div class="col-xs-4 body-column"><%- employee.Position.PositionName %></div>' +
        '</div>' +
        '<% }); %>'
    );

    let templateResult = templateTable({ 'employees': employees });

    $('#employeeTable').html(templateResult);
}

function getFilteredEmployeesModel(filterString) {
    let filtered = _.filter(employeesModel, function (employee) {
        return _.includes(employee.FirstName.toLowerCase(), filterString.toLowerCase()) ||
            _.includes(employee.LastName.toLowerCase(), filterString.toLowerCase()) ||
            _.includes(employee.Position.PositionName.toLowerCase(), filterString.toLowerCase());
    })

    return filtered;
}

function getEmployeeModelById(id) {
    let foundEmployee = null;

    // Used https://api.jquery.com/jquery.grep/ to make it easier.
    $.grep(employeesModel, function (n, i) {
        if (n._id == id) {
            foundEmployee = _.cloneDeep(n);
        }
    })

    return foundEmployee;
}

$(document).ready(function () {
    initializeEmployeesModel();

    $("#employeeSearch").on("keyup", function () {
        let employee = getFilteredEmployeesModel($(this).val());
        refreshEmployeeRows(employee);
    });

    $(document).on('click', '.body-row', function () {
        let clickedEmployee = getEmployeeModelById($(this).attr("data-id"));

        // Ignore null employees.
        if (clickedEmployee != null) {
            clickedEmployee.HireDate = moment(clickedEmployee.HireDate).format('LLLL');

            let template = _.template(
                '<strong>Address:</strong> <%- employee.AddressStreet %>, ' +
                '<%- employee.AddressCity %>, <%- employee.AddressState %>.' +
                '<%- employee.AddressZip %></br><strong>Phone Number:</strong> ' +
                '<%- employee.PhoneNum %> ext: <%- employee.Extension %></br>' +
                '<strong>Hire Date:</strong> <%- employee.HireDate %>'
            );

            let modal = template({ 'employee': clickedEmployee });
            showGenericModal(clickedEmployee.FirstName + ' ' + clickedEmployee.LastName, modal);
        }
    });
})