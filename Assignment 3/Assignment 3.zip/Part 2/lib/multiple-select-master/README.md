# Multiple Select

Multiple select is a jQuery plugin to select multiple elements with checkboxes :).

To get started checkout examples and documentation at <http://multiple-select.wenzhixin.net.cn>.

## Examples

* http://multiple-select.wenzhixin.net.cn/examples
* http://multiple-select-live.wenzhixin.net.cn/

## Changelog

[CHANGELOG](https://github.com/wenzhixin/multiple-select/blob/master/CHANGELOG.md)

## LICENSE

[The MIT License](https://github.com/wenzhixin/multiple-select/blob/master/LICENSE)
