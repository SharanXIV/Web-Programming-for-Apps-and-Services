---
id: themes
title: Themes
---

The Themes of Multiple Select.

<div id="codefund"></div>

Example: [The Themes](/examples#themes.html)

## bootstrap

Support for bootstrap v3 and bootstrap v4.

```
import 'multiple-select/dist/themes/bootstrap.css'
```
